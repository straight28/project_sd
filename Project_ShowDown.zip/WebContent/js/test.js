
/* 다른 페이지로 넘어가는 자바스크립트 */
 function list(page){
	 location.href =
	"DO?command=userboard&curPage="+page;
 }
